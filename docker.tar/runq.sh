#! /bin/sh
sleep 0.1 && rlwrap -pblue q -p $PORT -u $QHOME/auth.txt
